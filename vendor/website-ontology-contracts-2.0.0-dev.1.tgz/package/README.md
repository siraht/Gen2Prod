# `@website-ontology/contracts`

This package is the language-neutral protocol boundary between SiteSpec,
Gen2Prod, and SiteOps. The JSON Schema 2020-12 files in `schema/` and their
generated conformance fixtures are normative. Generated TypeScript declarations,
the embedded schema bundle, AJV helpers, and runtime utilities are projections of
that contract.

## Modules

- `core`: canonical entities, strict common envelopes, typed content and
  requirements, and the canonical graph.
- `artifacts`: immutable artifact references, revision sets, design candidates,
  visual targets, returned manifests, and design-system releases.
- `correspondence`: semantic-to-normal-form-to-source-to-rendered edges.
- `results`: assertions, measurements, requirement results, required actions,
  and result manifests.

Unknown top-level fields are rejected. Project-specific values belong only under
`extensions` keys containing a namespace such as `northstar.experiment`.

## Subject-reference rules

Canonical subjects have the form `sitespec://<namespace>/<kind>/<id>` with two or
more path segments. Namespace characters are lower-case ASCII letters, digits,
and interior hyphens. Path segments are lower-case ASCII letters/digits plus
interior `.`, `_`, `~`, and `-` characters. Empty, upper-case, percent-escaped,
leading/trailing separator, and single-segment paths are rejected.

Reserved or non-ASCII authoring labels are not escaped into identity. Authors
assign a stable lower-case ID and keep the human label in `title`. Comparison is
byte-for-byte on canonical serialized references. A title, route, filename,
source symbol, provider project ID, or DOM location may change without changing
the subject.

## Revisions

Canonical JSON sorts object keys, preserves array order, normalizes negative zero,
and rejects non-finite numbers or non-plain objects. Semantic hashes exclude
`revision`, source locations, transformation provenance, diagnostics, and
generated/captured timestamps.
Entity hashes include the semantic revisions of declared owned dependencies so a
slot change propagates to its section, composition, page, site, and project while
unrelated pages and identity-only references remain current.

## Build and conformance

From the repository root:

```text
pnpm contracts:build
pnpm vitest run tests/contracts/contracts.test.ts
```

The build regenerates TypeScript declarations, the schema bundle, the 119-entity
Northstar fixture, positive boundary fixtures, and adversarial fixtures. Gen2Prod
uses an explicit `file:/data/projects/WebsiteOntology/packages/contracts` link
only during coordinated development; published integration must pin an immutable
package version.
